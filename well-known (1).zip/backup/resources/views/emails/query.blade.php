<h2>New Query Received</h2>

<p><strong>Name:</strong> {{ $query['name'] }}</p>
<p><strong>Email:</strong> {{ $query['email'] }}</p>
<p><strong>Phone:</strong> {{ $query['phone'] }}</p>
<p><strong>Query:</strong> {{ $query['project_brief'] }}</p>
