<?php

namespace App\Livewire\Bacancypage;

use Livewire\Component;

class Modal extends Component
{
    public function render()
    {
        return view('livewire.bacancypage.modal');
    }
}
