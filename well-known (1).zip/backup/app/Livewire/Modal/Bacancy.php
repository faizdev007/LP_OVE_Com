<?php

namespace App\Livewire\Modal;

use Livewire\Component;

class Bacancy extends Component
{
    public function render()
    {
        return view('livewire.modal.bacancy');
    }
}
