
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'clients' => 'array',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'clients' => 'array',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<!-- If you do not have a consistent goal in life, you can not live it in a consistent way. - Marcus Aurelius -->
<div class="flex flex-row gap-5 overflow-x-auto scrollbar-hide px-2 sm:px-0 md:justify-center">
    <?php if (isset($component)) { $__componentOriginal687c686bb5a85506176f4c42fb855745 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal687c686bb5a85506176f4c42fb855745 = $attributes; } ?>
<?php $component = App\View\Components\AutoSlider::resolve(['cardmd' => 3,'cardlg' => 4,'cardxl' => 4,'card2xl' => 4,'interval' => 4000] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auto-slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AutoSlider::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w-full">
            <article class="snap-start flex-shrink-0 bg-bacancy-primary text-white rounded-lg shadow-lg overflow-hidden flex flex-col items-center">
                <video
                    class="object-cover aspect-[2/3] w-full"
                    controls
                    preload="metadata"
                    loading="lazy"
                    poster="<?php echo e(asset($client['poster'])); ?>"
                    title="Testimonial by <?php echo e($client['name']); ?>"
                >
                    <source src="<?php echo e($client['video']); ?>" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
                <div class="py-3 px-2 text-center">
                    <span class="text-lg font-semibold"><?php echo e($client['name']); ?></span>
                    <p class="text-sm"><?php echo e($client['title']); ?></p>
                </div>
            </article>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal687c686bb5a85506176f4c42fb855745)): ?>
<?php $attributes = $__attributesOriginal687c686bb5a85506176f4c42fb855745; ?>
<?php unset($__attributesOriginal687c686bb5a85506176f4c42fb855745); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal687c686bb5a85506176f4c42fb855745)): ?>
<?php $component = $__componentOriginal687c686bb5a85506176f4c42fb855745; ?>
<?php unset($__componentOriginal687c686bb5a85506176f4c42fb855745); ?>
<?php endif; ?>
</div><?php /**PATH /home3/oveau/public_html/resources/views/components/bacancypage/client-card.blade.php ENDPATH**/ ?>